# FILENAME: ML_API_GoogleMaps.py
# VERSION: 0.11
#######################################
# CHANGE LOG
#######################################
# 1. Added debug_mileage as a required argument for get_route_distance function.

import logging
import requests
from secret.ML_config import ROUTES_API_KEY

def get_route_distance(locations, debug_mileage):
    if debug_mileage:
        logging.debug(f"Calculating route distance for locations: {locations}")
    
    if len(locations) < 2:
        return 0, [], ""
    
    waypoints = '|'.join([f"{lat},{lng}" for lat, lng in locations])
    url = f"https://maps.googleapis.com/maps/api/directions/json?origin={locations[0][0]},{locations[0][1]}&destination={locations[-1][0]},{locations[-1][1]}&waypoints={waypoints}&mode=driving&avoid=highways&key={ROUTES_API_KEY}"
    
    if debug_mileage:
        logging.debug(f"Request URL: {url}")  # Log the URL for debugging
    
    response = requests.get(url)
    directions = response.json()
    
    if debug_mileage:
        logging.debug(f"Directions API response: {directions}")
    
    if directions['status'] == 'ZERO_RESULTS':
        logging.warning(f"No route found for locations: {locations}")
        return 0, [], ""
    elif directions['status'] != 'OK':
        logging.error(f"Error fetching route: {directions['status']}")
        raise Exception(f"Error fetching route: {directions['status']}")
    
    route = directions['routes'][0]
    legs = route['legs']
    total_distance = sum(leg['distance']['value'] for leg in legs) / 1000.0 # convert meters to kilometers

    if debug_mileage:
        logging.debug(f"Total distance: {total_distance}")
    
    map_link = f"https://www.google.com/maps/dir/?api=1&origin={locations[0][0]},{locations[0][1]}&destination={locations[-1][0]},{locations[-1][1]}&travelmode=driving&waypoints={waypoints}"
    
    return round(total_distance, 2), [leg['end_address'] for leg in legs], map_link
